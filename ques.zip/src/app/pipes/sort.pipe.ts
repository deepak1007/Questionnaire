import { Pipe, PipeTransform } from '@angular/core';
import { Question } from '../services/data.model';

@Pipe({
  name: 'sort'
})
export class SortPipe implements PipeTransform {

  transform(questions : Question[], fieldName: string=null): Question[] {
    return questions.sort(
      (question1, question2) =>  {
        const a = new Date(question1.answeredAt).getTime()
        const b = new Date(question2.answeredAt).getTime();
        return a-b
      }
    )
  }

}
